package com.example.fundamentalpertama.AllPage

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.text.HtmlCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.fundamentalpertama.API.ApiViewModel.DataDicodingEventViewModel
import com.example.fundamentalpertama.API.DataDicodingEvent
import com.example.fundamentalpertama.NetworkMonitor.NetworkMonitor
import org.jsoup.Jsoup

@Composable
fun PageDetail(
    getId: Int
) {
    val dataDicodingEventViewModel: DataDicodingEventViewModel = viewModel()
    var dataDicodingEventDetail by remember { mutableStateOf<DataDicodingEvent?>(null) }
    val createContext = LocalContext.current
    var isLoading by remember { mutableStateOf(true) }
    val netWorkMonitor = remember { NetworkMonitor(context = createContext) }
    val dataDicodingEventDetailCache = dataDicodingEventViewModel.eventDetailCache.find { it.id == getId }

    if (dataDicodingEventDetailCache != null) {
        dataDicodingEventDetail = dataDicodingEventDetailCache
        isLoading = false
    } else {
        isLoading = true
    }

    fun fetchPagedetail() {
        dataDicodingEventViewModel.fetchDetailDicodingEvent(
            getId = getId,
            onResult = { fetch ->
                dataDicodingEventDetail = fetch
                isLoading = false
            }
        )
    }

    LaunchedEffect(getId) {
        netWorkMonitor.startNetworkCallback(
            onNetworkAvailable = {
                fetchPagedetail()
            }
        )
        if (dataDicodingEventDetailCache == null) {
            fetchPagedetail()
        }
    }

    if (isLoading) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            content = {
                CircularProgressIndicator(color = Color(0xFFEE299B))
                Text(
                    "Loading...",
                    fontSize = 10.sp,
                    modifier = Modifier.padding(5.dp)
                )
            }
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            content = {
                dataDicodingEventDetail?.let { data ->
                    Image(
                        painter = rememberAsyncImagePainter(data.imageLogo),
                        contentDescription = "image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .padding(10.dp)
                            .shadow(5.dp, RoundedCornerShape(10.dp))
                            .fillMaxWidth()
                            .height(300.dp)
                    )
                    Box(
                        modifier = Modifier
                            .padding(start = 10.dp, bottom = 10.dp, top = 20.dp)
                            .border(
                                width = 2.dp,
                                shape = RoundedCornerShape(5.dp),
                                color = Color(0xFF565656)
                            ),
                        content = {
                            Text(
                                text = data.category,
                                modifier = Modifier.padding(
                                    top = 0.dp,
                                    bottom = 0.dp,
                                    start = 10.dp,
                                    end = 10.dp
                                ),
                                color = Color(0xFF565656),
                                fontSize = 10.sp
                            )
                        }
                    )
                    Text(
                        text = data.name,
                        fontSize = 30.sp,
                        modifier = Modifier.padding(start = 10.dp, bottom = 10.dp),
                        lineHeight = 40.sp
                    )

                    Text(
                        text = "Diselenggarakan oleh: ${data.ownerName}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Light,
                        color = Color(0xF0757575),
                        modifier = Modifier.padding(start = 10.dp, bottom = 20.dp)
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        content = {
                            Text(text = "Dibuka Sampai:")
                            Text(
                                text = data.beginTime,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = "Sisa Kuota:")
                            Text(
                                text = "${data.quota - data.registrants}",
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = "Registrant:")
                            Text(
                                text = data.registrants.toString(),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )

                    Text(
                        text = "Deskripsi",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 20.dp)
                    )

                    val document = Jsoup.parse(data.description)
                    val images = document.select("img").map { it.attr("src") }
                    val htmlContent = document.body().html()

                    images.forEach { imageUrl ->
                        Image(
                            painter = rememberAsyncImagePainter(imageUrl),
                            contentDescription = "image from description",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(10.dp)
                                .shadow(5.dp, RoundedCornerShape(10.dp))
                                .fillMaxWidth()
                                .height(200.dp)
                        )

                    Text(
                        text = HtmlCompat.fromHtml(htmlContent, HtmlCompat.FROM_HTML_MODE_LEGACY).toString(),
                        modifier = Modifier
                            .padding(10.dp)
                            .fillMaxSize(),
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        textAlign = TextAlign.Justify
                    )
                    }

                    Button(
                        modifier = Modifier
                            .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 50.dp)
                            .fillMaxWidth()
                            .height(60.dp)
                            .border(2.dp, Color(0xFFEE299B), RoundedCornerShape(10.dp)),
                        colors = ButtonDefaults.buttonColors(
                            Color.Transparent
                        ),
                        onClick = {
                            val intent =
                                Intent(Intent.ACTION_VIEW, Uri.parse(data.link))
                            createContext.startActivity(intent)
                        },
                        content = {
                            Text(text = "Registrasi", color = Color(0xFFEE299B))
                        }
                    )
                }
            }
        )
    }
}
